<?php
$host = "localhost";
$user = "root";
$password = ""; // Your MySQL password
$db = "vms";

// Connect to MySQL
$conn = new mysqli($host, $user, $password, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get data from form
$name = $_POST['name'];
$email = $_POST['email'];
$vehicle_type = $_POST['vehicle_type'];
$date_of_journey = $_POST['date_of_journey'];
$seat_number = $_POST['seat_number'];

// Insert data into table
$sql = "INSERT INTO booking (name, email, vehicle_type, date_of_journey, seat_number)
        VALUES ('$name', '$email', '$vehicle_type', '$date_of_journey', '$seat_number')";

if ($conn->query($sql) === TRUE) {
    echo "<h2>Ticket booked successfully!</h2>";
    echo "<a href='ticket_booking.html'>Book Another</a>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>