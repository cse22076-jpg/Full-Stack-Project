<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>VMS-Paria Transport</title>
<link rel="icon" type="image/x-icon" href="logo3.ico">
</head>

<body>
<?php
$uname=$_POST["uname"];
$psw=$_POST["psw"];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "vms";
$uname1="";
$psw1="";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT username,password from customer where username='".$uname."'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  // output data of each row
  while($row = mysqli_fetch_assoc($result)) {
    	$uname1=$row["username"];
		$psw1=$row["password"];
  }
} else {
  echo "0 results";
}

mysqli_close($conn);
if($uname==$uname1 && $psw==$psw1)
echo "<h2> Successful login</h2>";
else
header("location:login.html");
?>
</body>
</html>
