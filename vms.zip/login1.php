<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>VMS Susmita Transport</title>
<link rel="icon" type="image/x-icon" href="logo3.ico">
</head>

<body>
<?php
$uname=$_POST["uname"];
$psw=$_POST["psw"];
$uname1="";
$pass1="";
$servername = "localhost"; // localhost is the server name
$username = "root"; //username  b y default is root
$password = ""; // no password
$dbname = "vms"; //vms

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
// $sql = "select username,password from customer where username='".$uname."'";
$sql = "select user,pass from customer where user='".$uname."'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  // output data of each row
  while($row = mysqli_fetch_assoc($result)) {
		$uname1=$row["user"];
		$pass1=$row["pass"];
  }
} else {
  echo "0 results";
}


if($uname==$uname1 && $psw==$pass1)
// echo "<h2> Successful login</h2>";
header("location:home1.html");
else
header("location:login1.html");
mysqli_close($conn);
?>
</body>
</html>
