<?php $val=substr(md5(rand()),0,6); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>VMS-Paria Transport</title>
<link rel="icon" type="image/x-icon" href="logo3.ico">
<style type="text/css">
<!--
#Layer1 {
	position:absolute;
	width:206px;
	height:175px;
	z-index:1;
	left: 2px;
	top: 7px;
}
#Layer2 {
	position:absolute;
	width:1075px;
	height:190px;
	z-index:1;
	left: 205px;
	top: 0px;
}
.style1 {
	font-size: xx-large;
	font-weight: bold;
	color: #FF0000;
}
#Layer3 {
	position:absolute;
	width:552px;
	height:59px;
	z-index:1;
	left: 464px;
	top: 49px;
}
.style2 {
	font-size: x-large;
	color: #6600FF;
	font-family: "Courier New", Courier, monospace;
}
#Layer4 {
	position:absolute;
	width:200px;
	height:55px;
	z-index:2;
	left: 2px;
	top: 128px;
}
.style3 {
	color: #00FF00;
	font-weight: bold;
}
#Layer5 {
	position:absolute;
	width:184px;
	height:46px;
	z-index:3;
	left: 345px;
	top: 142px;
}
.style4 {
	color: #000099;
	font-weight: bold;
}
#Layer6 {
	position:absolute;
	width:323px;
	height:54px;
	z-index:4;
	left: 739px;
	top: 137px;
}
.style5 {
	font-size: 18px;
	color: #FF0066;
}
#Layer7 {
	position:absolute;
	width:791px;
	height:425px;
	z-index:2;
	left: 338px;
	top: 253px;
}
-->
</style>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {box-sizing: border-box;}
body {
	font-family: Verdana, sans-serif;
	background-color: #FFFFCC;
}
.mySlides {display: none;}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  animation-name: fade;
  animation-duration: 1.5s;
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 11px}
}
#Layer8 {
	position:absolute;
	width:200px;
	height:338px;
	z-index:3;
	left: 1px;
	top: 316px;
}
</style>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
#mySidenav a {
  position: absolute;
  left: -81px;
  transition: 0.3s;
  padding: 15px;
  width: 150px;
  text-decoration: none;
  font-size: 20px;
  color: white;
  border-radius: 0 5px 5px 0;
}

#mySidenav a:hover {
  left: 0;
}

#about {
  top: 19px;
  background-color: #04AA6D;
}

#blog {
  top: 80px;
  background-color: #2196F3;
}

#projects {
  top: 160px;
  background-color: #f44336;
}

#contact {
  top: 220px;
  background-color: #555
}
.style6 {color: #00FF00}
.style7 {color: #FFFF33}
.style8 {color: #000066}
</style>
<script type="text/javascript"> 
function chk() 
{ 
	var captcha = "<?php echo $val; ?>";
	var name=document.form1.textfield.value; 
	var address=document.form1.textarea.value;
	var email=document.form1.textfield3.value;
	var phno=document.form1.textfield2.value;
	var user=document.form1.textfield5.value;
	var pass=document.form1.textfield6.value;
	var captcha1=document.form1.textfield4.value;
	if(name==""||address==""||email==""||phno==""||captcha1==""||user==""||pass=="")
	alert("field can not be empty");
	else if(!(/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/.test(email)))
	alert("invalid email");
	else if(phno.length!=10)
	alert("invalied Phone Number");
	else if(captcha!=captcha1)
	alert("Invalid catcha");
	else
	window.location.href = "register_logic.php?n="+name+"&address="+address+"&ph="+phno+"&email="+email+"&user="+user+"&pass="+pass; 
} 
</script> 

</head>

<body bgcolor="#FFFFCC">
<div id="Layer1"><img src="logo1.png" width="204" height="192" />
  <div id="Layer2">
    <div align="center" class="style1">PARIA TRANSPORT </div>
    <div id="Layer6">
      <div align="center" class="style5"><img src="email.jpg" width="59" height="57" />pariatransport@gmail.com</div>
    </div>
    <div class="style4" id="Layer5"><img src="whatsapp.png" width="52" height="45" /> 67890432167</div>
    <div id="Layer4"><img src="phone.jpg" width="49" height="63" /><span class="style3">1234567890</span></div>
    <div id="Layer3">
      <div align="center" class="style2">new dimension in transport world </div>
    </div>
  </div>
</div>
<div id="Layer7">
  <form id="form1" name="form1" method="post" action="register_logic.php">
    <p align="center" class="style1">REGISTRATION FORM  </p>
    <table width="790" height="529" border="0">
      <tr>
        <td><div align="center" class="style3 style8">Name of the Customer </div></td>
        <td><input type="text" name="textfield" placeholder="please enter your name"/></td>
      </tr>
      <tr>
        <td><div align="center" class="style3 style8">Postal Address </div></td>
        <td><textarea name="textarea" placeholder="enter your address"></textarea></td>
      </tr>
      <tr>
        <td><div align="center" class="style3 style8">Phone Number </div></td>
        <td><input type="text" name="textfield2" placeholder="enter your phone number"/></td>
      </tr>
      <tr>
        <td><div align="center" class="style3 style8">Email ID
        </div></td>
        <td><span class="style3 style8">
          <input type="text" name="textfield3" placeholder="enter your email id"/>
        </span></td>
      </tr>
      <tr>
        <td class="style4"><div align="center" class="style8">User Name </div></td>
        <td><input type="text" name="textfield5" /></td>
      </tr>
      <tr>
        <td class="style4"><div align="center" class="style4">Password</div></td>
        <td><input type="text" name="textfield6" /></td>
      </tr>
      <tr>
        <td><div align="center" class="style3 style8">
            <p>Captcha <font color="#FF3300"> <?php echo $val; ?></font> </p>
        </div></td>
        <td><input type="text" name="textfield4" /></td>
      </tr>
      <tr>
        <td><div align="center"><span class="style6"><span class="style7"><span class="style8"></span></span></span>
                <input type="button" name="Submit" value="Submit" onclick="chk();"/>
        </div></td>
        <td><input type="reset" name="Submit2" value="Clear Data" /></td>
      </tr>
    </table>
    <p>&nbsp;  </p>
  </form>
</div>

</body>
</html>
