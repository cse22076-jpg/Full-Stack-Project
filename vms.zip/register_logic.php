<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>VMS-Paria Transport</title>
<link rel="icon" type="image/x-icon" href="logo3.ico">
</head>
<body>
<?php
$name=$_GET["n"];
$address=$_GET["address"];
$phno=$_GET["ph"];
$email=$_GET["email"];
$user=$_GET["user"];
$pass=$_GET["pass"];
//database connectivity
$servername = "localhost"; // localhost is the server name
$username = "root"; //username  b y default is root
$password = ""; // no password
$dbname = "vms"; //vms

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
//insert values in database (table-customer)
$sql = "INSERT INTO customer VALUES ('".$name."','".$address."','".$phno."','".$email."','".$user."','".$pass."')"; //sql query
if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
header("Location:login1.html");

$conn->close();
?>

</body>
</html>
