<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>VMC-Susmita Transport</title>
<link rel="icon" type="image/x-icon" href="logo3.ico">
<style type="text/css">
<!--
#Layer1 {
	position:absolute;
	width:194px;
	height:170px;
	z-index:1;
	top: 3px;
}
#Layer2 {
	position:absolute;
	width:1149px;
	height:174px;
	z-index:2;
	left: 197px;
	top: 2px;
}
.style2 {
	font-size: 36px;
	color: #000099;
}
#Layer3 {
	position:absolute;
	width:536px;
	height:42px;
	z-index:3;
	left: 645px;
	top: 50px;
}
.style3 {font-size: 24px; color: #000099; }
.style4 {color: #00CCFF}
#Layer4 {
	position:absolute;
	width:213px;
	height:38px;
	z-index:4;
	left: 2px;
	top: 128px;
}
#Layer5 {
	position:absolute;
	width:250px;
	height:44px;
	z-index:5;
	left: 627px;
	top: 130px;
}
.style8 {color: #0000FF}
#Layer6 {
	position:absolute;
	width:327px;
	height:57px;
	z-index:6;
	left: 806px;
	top: 112px;
}
.style9 {
	font-size: large;
	color: #660066;
}
</style>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {box-sizing: border-box}
body {font-family: Verdana, sans-serif; margin:0}
.mySlides {display: none}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 266px;
  width: 77px;
  padding: 16px;
  margin-top: -22px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
}

/* Position the "next button" to the right */
.next {
  right: 74px;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover, .next:hover {
  background-color: rgba(0,0,0,0.8);
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: #717171;
}

/* Fading animation */
.fade {
  animation-name: fade;
  animation-duration: 1.5s;
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .prev, .next,.text {font-size: 11px}
}
.dot1 {  cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}
.fade1 {  animation-name: fade;
  animation-duration: 1.5s;
}
.next1 {  cursor: pointer;
  position: absolute;
  top: 266px;
  width: 77px;
  padding: 16px;
  margin-top: -22px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
}
.next1 {  right: 74px;
  border-radius: 3px 0 0 3px;
}
.prev1 {  cursor: pointer;
  position: absolute;
  top: 266px;
  width: 77px;
  padding: 16px;
  margin-top: -22px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
}
.dot11 {cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}
.fade2 {  animation-name: fade;
  animation-duration: 1.5s;
}
.next11 {cursor: pointer;
  position: absolute;
  top: 266px;
  width: 77px;
  padding: 16px;
  margin-top: -22px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
}
.next11 {right: 74px;
  border-radius: 3px 0 0 3px;
}
.prev11 {
	cursor: pointer;
	position: absolute;
	top: 266px;
	width: 77px;
	padding: 16px;
	margin-top: -22px;
	color: white;
	font-weight: bold;
	font-size: 18px;
	transition: 0.6s ease;
	border-radius: 0 3px 3px 0;
	user-select: none;
	left: -1px;
}
.dot111 {cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}
.fade3 {  animation-name: fade;
  animation-duration: 1.5s;
}
.next111 {cursor: pointer;
  position: absolute;
  top: 266px;
  width: 77px;
  padding: 16px;
  margin-top: -22px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
}
.next111 {right: 74px;
  border-radius: 3px 0 0 3px;
}
#Layer7 {
	position:absolute;
	width:483px;
	height:418px;
	z-index:7;
	left: 882px;
	top: 225px;
}
#Layer8 {
	position:absolute;
	width:223px;
	height:360px;
	z-index:8;
	left: 1px;
	top: 214px;
}
</style>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
#mySidenav a {
	position: absolute;
	left: -48px;
	transition: 0.3s;
	padding: 15px;
	width: 146px;
	text-decoration: none;
	font-size: 20px;
	color: white;
	border-radius: 0 5px 5px 0;
	height: 57px;
}

#mySidenav a:hover {
  left: 0;
}

#about {
  top: 0px;
  background-color: #04AA6D;
}

#blog {
  top: 96px;
  background-color: #2196F3;
}

#projects {
  top: 181px;
  background-color: #f44336;
}

#contact {
  top: 278px;
  background-color: #555
}
.style11 {font-size: large}
#Layer9 {
	position:absolute;
	width:821px;
	height:140px;
	z-index:6;
	left: 413px;
	top: 280px;
}
</style>

-->

</head>

<body background="pic8,jpg.jpg">
<div id="Layer1"><img src="logo2.jpg" width="195" height="175" /></div>
<div id="Layer5"><img src="whatsapp.png" width="55" height="43" /><span class="style8">7586963259</span></div>
<div class="style2" id="Layer2">
  <div align="center">PARIA TRANSPORT </div>
  <div class="style3" id="Layer3">
  <div align="center" class="style4">new dimension in transport world </div>
</div>
<div id="Layer4">
  <div align="left"><img src="phone.jpg" width="41" height="49" /><span class="style7 style11">7586963259</span></div>
</div>
<div id="Layer6"><img src="email.jpg" width="68" height="62" /><span class="style9">Pariatransport@gmail.com</span></div>
</div>
<div id="Layer9">
  <form id="form1" name="form1" method="post" action="">
    <p>Transport type 
      <input type="text" name="textfield" />
      <input type="submit" name="submit" value="Search" />
  </p>
    <table width="822" height="86" border="1">
      <tr>
        <th>Vechile Type</th>
        <th>Origin</th>
        <th>Destination</th>
        <th>Time</th>
        <th>Service</th>
        <th>AC_NONAC</th>
        <th>Book Seat</th>
      </tr>
<?php 

$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "vms"; 
$type=""; 
$origin=""; 
$dest=""; 
$time=""; 
$service="";
$acnonac="";
if (isset($_POST['submit']))  
{   
$type=$_POST["textfield"];
// Create connection 
$conn = new mysqli($servername, $username, $password, $dbname); 
// Check connection 
if ($conn->connect_error) { 
  die("Connection failed: " . $conn->connect_error); 
} 
 
$sql = "SELECT * from transport where type='".$type."'"; 
$result = mysqli_query($conn,$sql); 
?> 
 
 
   <?php  if (mysqli_num_rows($result)> 0) { 
  // output data of each row 
  while($row = mysqli_fetch_assoc($result)) { 
  ?> 
    <tr> 
        <td><?php echo $row["type"]; ?></td> 
        <td><?php echo $row["origin"]; ?></td> 
        <td><?php echo $row["destination"]; ?></td> 
        <td><?php echo $row["time"]; ?></td> 
        <td><?php echo $row["service"]; ?></td>
		<td><?php echo $row["ac_nonac"]; ?></td> 
        <td><a href="ticket_booking.html"> Book Ticket </a></td> 
      </tr>  
 <?php }} else { 
  echo "0 results"; 
  }
  $conn->close();
  }
      ?>
    </table>
    <p>&nbsp;  </p>
  </form>
</div>

</body>
</html>
